/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blockmarket;

/**
 *
 * @author Manny
 */
public class BlockData {
    private String seller;
    private String buyer;
    private String currencyName;
    private double currency, fee;
    private String transactionType; // purchase, return, gift
    
    BlockData(){
        seller = "NULL";
        buyer = "NULL";
        currencyName = "NULL";
        currency = 0; fee = 0;
        transactionType = "NULL";
    }
    
    BlockData(String s, String b, String cn, double c, double f, String tt){
        seller = s;
        buyer = b;
        currencyName = cn;
        currency = c; fee = f;
        transactionType = tt;
    }
}
