/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blockmarket;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

/**
 *
 * @author Manny
 */
public class MiningHelper {
    private MessageDigest hasher;
    private Block targetBlock;
    private BlockChain targetBlockChain;
    private String targetBlockAsString;
    
    public MiningHelper() throws NoSuchAlgorithmException {
        hasher = MessageDigest.getInstance("SHA-256");
    }
    
    public MiningHelper(Block b, BlockChain tbc) throws NoSuchAlgorithmException {
        this();
        targetBlock = b;
        targetBlockChain = tbc;
    }
    
    public void setHasher(MessageDigest md) throws NoSuchAlgorithmException { hasher = md; }
    public void setTargetBlock(Block b) { targetBlock = b; }
    public void setTargetBlockChain(BlockChain tbc) { targetBlockChain = tbc; }
    public MessageDigest getHasher() { return hasher; }
    public Block getTargetBlock() { return targetBlock; }
    public BlockChain getTargetBlockChain() { return targetBlockChain; } 
   
    public short findNonce(){
        short temp_nonce = 0;
        String temp_hash;
        Random rand = new Random();
        temp_nonce = (short) rand.nextInt(Short.MAX_VALUE); // may produce duplicate values
        targetBlock.setNonce(temp_nonce);
        
        
    }
    
}
