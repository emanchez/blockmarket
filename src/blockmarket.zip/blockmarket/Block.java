/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blockmarket;

import java.util.Date;

/**
 *
 * @author Manny
 */
public class Block {
    private int blockNumber;
    private short nonce;
    private long timestamp;
    private BlockData data;
    private String hash, prevHash;
    private Date date = new Date();
    
    public Block(){ // GENESIS BLOCK
        timestamp = date.getTime() / 1000; // seconds from epoch
        blockNumber = 0;
        nonce = 0;
        hash = "00000000000000000000000000000000000000000000000000000000000000000";
        
    }
    public Block(int bn, short n, BlockData d, 
            String h, String p) {
        timestamp = date.getTime() / 1000; // seconds from epoch
        blockNumber = bn;
        nonce = n;
        data = d;
        hash = h;
        prevHash = h;
    }
    
    public void setBlockNumber(int x) { blockNumber = x; }
    public void setNonce(short x) { nonce = x; }
    public void setBlockData(BlockData d) { data = d; }
    public void setHash(String h) { hash = h; }
    public void setPreviousHash(String p) { prevHash = p; }
    
    public int getBlockNumber() { return blockNumber;}
    public short getNonce() { return nonce; }
    public BlockData getBlockData() { return data; }
    public String getHash() { return hash; }
    public String getPreviousHash() { return prevHash; }
}    
