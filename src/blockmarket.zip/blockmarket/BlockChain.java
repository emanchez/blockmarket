/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blockmarket;

import java.util.*;

/**
 *
 * @author Manny
 */
public class BlockChain {
    //private Hashtable<String, Block> chain;
    private Block[] chain;
    private Block GenesisBlock = new Block();
    private Block lastBlock;
    private int size;
    private int difficulty; 
    
    // CONSTRUCTOR
    public BlockChain(){
        chain = new Block[1000];
        difficulty = 3;
        chain[0] = GenesisBlock;
        size += 1;
    }
    
    public BlockChain(int num, int d){
        chain = new Block[num];
        difficulty = d;
        chain[0] = GenesisBlock;
        size += 1;
    }
    
    public void insertNewBlock(Block b){
        if (isValidBlock(b)){
            chain[size++] = b;
        }
        
    }
    public boolean isValidBlock(Block b){
        // TODO: check to see if block has a valid hash
        if (!isValidNonce(b.getNonce())){
            return false;
        }
        
        if (!isValidPrevHash(b.getPreviousHash())){
            return false;
        }
        
        if (!isValidHash(b.getHash())){
            return false;
        }
        
        return true;
    }
    
    public boolean isValidNonce(short n){
        if (n <= 0){
            return false;
        }
        return true;
    }
    
    public boolean isValidHash(String h){
        for (int i = 0; i < difficulty; i++){
            if (h.charAt(i) != '0'){
                return false;
            }
        }
        return true;
    }
    
    
    public boolean isValidPrevHash(String h){
        return h.equals(chain[size-1].getHash());
    }
    
    
    
    public boolean validateChain(BlockChain otherBlockChain){
        // TODO: make a consensus protocol
        return true;
    }
    
}